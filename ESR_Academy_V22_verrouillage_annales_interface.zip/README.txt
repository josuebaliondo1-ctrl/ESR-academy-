ESR Academy - correctif interface annales

Contenu : index.html à publier à la racine du site Netlify.
Ce correctif bloque les clics sur les liens de la section Annales et affiche la demande d’abonnement.
Important : ce blocage est côté navigateur uniquement. Il ne protège pas les fichiers externes si leurs URL sont connues. Une protection réelle exige de retirer les URL publiques et de servir les fichiers via un backend avec contrôle d’abonnement.
